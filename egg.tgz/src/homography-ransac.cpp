// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit homography via RANSAC\n", stdout);
  return lionss_run_workload("homography-ransac");
}
