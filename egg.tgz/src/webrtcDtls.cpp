// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Handshake DTLS-SRTP\n", stdout);
  return lionss_run_workload("webrtcDtls");
}
