// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Track ORB features"); }
int main(){
  announce();
  return lionss_run_workload("orbTrack");
}
