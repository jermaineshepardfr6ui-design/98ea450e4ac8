# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(deltaV_budget src/deltaV_budget.cpp)
set_property(TARGET deltaV_budget PROPERTY CXX_STANDARD 11)
target_link_libraries(deltaV_budget lionss pthread)

add_executable(brightwater-7 src/brightwater-7.cpp)
set_property(TARGET brightwater-7 PROPERTY CXX_STANDARD 11)
target_link_libraries(brightwater-7 lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(harbor_light src/harbor_light.cpp)
set_property(TARGET harbor_light PROPERTY CXX_STANDARD 11)
target_link_libraries(harbor_light lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(telemetry-frame src/telemetry-frame.cpp)
set_property(TARGET telemetry-frame PROPERTY CXX_STANDARD 11)
target_link_libraries(telemetry-frame lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(jitProfile src/jitProfile.cpp)
set_property(TARGET jitProfile PROPERTY CXX_STANDARD 11)
target_link_libraries(jitProfile lionss pthread)

add_executable(BlueHeron src/BlueHeron.cpp)
set_property(TARGET BlueHeron PROPERTY CXX_STANDARD 11)
target_link_libraries(BlueHeron lionss pthread)

add_executable(skybox-dawn src/skybox-dawn.cpp)
set_property(TARGET skybox-dawn PROPERTY CXX_STANDARD 11)
target_link_libraries(skybox-dawn lionss pthread)

add_executable(hugepage_madv src/hugepage_madv.cpp)
set_property(TARGET hugepage_madv PROPERTY CXX_STANDARD 11)
target_link_libraries(hugepage_madv lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(squall src/squall.cpp)
set_property(TARGET squall PROPERTY CXX_STANDARD 11)
target_link_libraries(squall lionss pthread)

add_executable(AsciidocPdf src/AsciidocPdf.cpp)
set_property(TARGET AsciidocPdf PROPERTY CXX_STANDARD 11)
target_link_libraries(AsciidocPdf lionss pthread)

add_executable(Peregrine src/Peregrine.cpp)
set_property(TARGET Peregrine PROPERTY CXX_STANDARD 11)
target_link_libraries(Peregrine lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(bolt_reorder src/bolt_reorder.cpp)
set_property(TARGET bolt_reorder PROPERTY CXX_STANDARD 11)
target_link_libraries(bolt_reorder lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(mqtt-qos2 src/mqtt-qos2.cpp)
set_property(TARGET mqtt-qos2 PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-qos2 lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(orbTrack src/orbTrack.cpp)
set_property(TARGET orbTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(orbTrack lionss pthread)

